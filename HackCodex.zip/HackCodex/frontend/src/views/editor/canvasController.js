

const addNewPage = (store) => {
    store.addPage();
};

const removePage = (store, index) => {
    store.removePage(index);
};
