const aux = ( props ) => { return props.children; } 

export default aux;
