import React from "react";

// material-ui
import { makeStyles } from "@mui/styles";


const settings = () => {
    return (
        <div>
            <h1>Settings</h1>
        </div>
    );
};