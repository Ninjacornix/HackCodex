import React from 'react';

export const LandingPage = () => {
  return <div>LandingPage</div>;
};
